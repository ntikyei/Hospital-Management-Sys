class Patient:
    """Patient class"""

    def __init__(self, first_name, surname, age, mobile, postcode, address='', symptoms='', family_id=''):
        self.__first_name = first_name
        self.__surname = surname
        self.__age = age
        self.__mobile = mobile
        self.__postcode = postcode
        self.__address = address
        self.__symptoms = symptoms
        self.__doctor = "None"
        self.__family_id = family_id

    def full_name(self):
        return f"{self.__first_name} {self.__surname}"

    def get_doctor(self):
        return self.__doctor

    def link(self, doctor):
        self.__doctor = doctor

    def get_symptoms(self):
        return self.__symptoms

    def set_symptoms(self, symptoms):
        self.__symptoms = symptoms

    def get_address(self):
        return self.__address

    def set_address(self, address):
        self.__address = address

    def get_age(self):
        return self.__age

    def set_age(self, age):
        self.__age = age

    def get_mobile(self):
        return self.__mobile

    def set_mobile(self, mobile):
        self.__mobile = mobile

    def get_postcode(self):
        return self.__postcode

    def set_postcode(self, postcode):
        self.__postcode = postcode

    def get_first_name(self):
        return self.__first_name

    def set_first_name(self, first_name):
        self.__first_name = first_name

    def get_surname(self):
        return self.__surname

    def set_surname(self, surname):
        self.__surname = surname

    def get_family_id(self):
        return self.__family_id

    def set_family_id(self, family_id):
        self.__family_id = family_id

    def print_symptoms(self):
        symptoms = self.__symptoms if self.__symptoms else "(not recorded)"
        print(f"Symptoms: {symptoms}")

    def to_dict(self):
        """Convert patient to dictionary for file storage"""
        return {
            'first_name': self.__first_name,
            'surname': self.__surname,
            'age': self.__age,
            'mobile': self.__mobile,
            'postcode': self.__postcode,
            'address': self.__address,
            'symptoms': self.__symptoms,
            'doctor': self.__doctor,
            'family_id': self.__family_id
        }

    @staticmethod
    def from_dict(data):
        """Create patient from dictionary"""
        patient = Patient(
            data['first_name'],
            data['surname'],
            data['age'],
            data['mobile'],
            data['postcode'],
            data.get('address', ''),
            data.get('symptoms', ''),
            data.get('family_id', '')
        )
        patient.link(data.get('doctor', 'None'))
        return patient

    def __str__(self):
        return f"{self.full_name():<28}| {self.__doctor:<24}| {self.__age:>3} | {self.__mobile:<12} | {self.__postcode}"
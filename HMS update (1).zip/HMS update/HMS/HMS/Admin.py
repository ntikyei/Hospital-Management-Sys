from Doctor import Doctor
from Patient import Patient
import json
import os
from collections import defaultdict


class Admin:
    """A class that deals with the Admin operations"""

    def __init__(self, username, password, address=''):
        self.__username = username
        self.__password = password
        self.__address = address

    def view(self, a_list):
        if not a_list:
            print("No items.")
            return
        for index, item in enumerate(a_list, start=1):
            print(f"{index:3} | {item}")

    def login(self):
        print("-----Login-----")
        username = input("Enter the username: ")
        password = input("Enter the password: ")
        return username == self.__username and password == self.__password

    def find_index(self, index, items):
        return 0 <= index < len(items)

    def get_doctor_details(self):
        first_name = input("Enter the first name: ").strip()
        surname = input("Enter the surname: ").strip()
        speciality = input("Enter the speciality: ").strip()
        return first_name, surname, speciality

    def doctor_management(self, doctors, patients):
        print("-----Doctor Management-----")
        print(" 1 - Register")
        print(" 2 - View")
        print(" 3 - Update")
        print(" 4 - Delete")
        op = input("Input: ").strip()

        if op == '1':
            print("-----Register-----")
            first_name, surname, speciality = self.get_doctor_details()
            full = f"{first_name} {surname}"
            duplicate = False
            for d in doctors:
                if d.full_name().lower() == full.lower():
                    duplicate = True
                    break
            if duplicate:
                print("Doctor already exists.")
            else:
                doctors.append(Doctor(first_name, surname, speciality))
                print("Doctor added.")
        elif op == '2':
            print("-----List of Doctors-----")
            print("ID |          Full Name           |  Speciality")
            self.view(doctors)
        elif op == '3':
            if not doctors:
                print("No doctors to update.")
                return
            print("-----Update Doctor-----")
            print("ID |          Full Name           |  Speciality")
            self.view(doctors)
            try:
                idx = int(input("Select ID: ")) - 1
                if not self.find_index(idx, doctors):
                    print("Invalid ID.")
                    return
                print("Choose field:")
                print(" 1 First name")
                print(" 2 Surname")
                print(" 3 Speciality")
                choice = input("Input: ").strip()
                if choice == '1':
                    doctors[idx].set_first_name(input("New first name: ").strip())
                elif choice == '2':
                    doctors[idx].set_surname(input("New surname: ").strip())
                elif choice == '3':
                    doctors[idx].set_speciality(input("New speciality: ").strip())
                else:
                    print("Invalid choice.")
                    return
                print("Doctor updated.")
            except ValueError:
                print("Please enter a number.")
        elif op == '4':
            if not doctors:
                print("No doctors to delete.")
                return
            print("-----Delete Doctor-----")
            print("ID |          Full Name           |  Speciality")
            self.view(doctors)
            try:
                idx = int(input("Select ID: ")) - 1
                if not self.find_index(idx, doctors):
                    print("Invalid ID.")
                    return
                removed = doctors.pop(idx)
                # Unlink patients that were assigned to the removed doctor
                for p in patients:
                    if p.get_doctor() == removed.full_name():
                        p.link("None")
                print(f"Removed: {removed.full_name()}")
            except ValueError:
                print("Please enter a number.")
        else:
            print("Invalid option.")

    def view_patient(self, patients):
        print("-----View Patients-----")
        print("ID |          Full Name           |      Doctor`s Full Name      | Age |    Mobile     | Postcode")
        self.view(patients)

    def assign_doctor_to_patient(self, patients, doctors):
        if not patients or not doctors:
            print("Need both patients and doctors.")
            return
        print("-----Assign Doctor-----")
        self.view_patient(patients)
        try:
            p_idx = int(input("Patient ID: ")) - 1
            if not self.find_index(p_idx, patients):
                print("Invalid patient ID.")
                return
        except ValueError:
            print("Please enter a number.")
            return

        print("-----Doctors-----")
        print("ID |          Full Name           |  Speciality")
        self.view(doctors)
        try:
            d_idx = int(input("Doctor ID: ")) - 1
            if not self.find_index(d_idx, doctors):
                print("Invalid doctor ID.")
                return
        except ValueError:
            print("Please enter a number.")
            return

        doctor_name = doctors[d_idx].full_name()
        patients[p_idx].link(doctor_name)
        doctors[d_idx].add_patient(patients[p_idx])
        print("Assigned.")

    def discharge(self, patients, discharged_patients, doctors):
        if not patients:
            print("No patients to discharge.")
            return
        print("-----Discharge Patient-----")
        self.view_patient(patients)
        try:
            idx = int(input("Patient ID: ")) - 1
            if not self.find_index(idx, patients):
                print("Invalid patient ID.")
                return
            patient = patients.pop(idx)
            # Remove patient from any doctor's internal list
            for d in doctors:
                d.remove_patient(patient)
            discharged_patients.append(patient)
            print("Patient discharged.")
        except ValueError:
            print("Please enter a number.")

    def view_discharge(self, discharged_patients):
        print("-----Discharged Patients-----")
        print("ID |          Full Name           |      Doctor`s Full Name      | Age |    Mobile     | Postcode")
        self.view(discharged_patients)

    def update_details(self):
        print("-----Update Admin-----")
        print(" 1 Username")
        print(" 2 Password")
        print(" 3 Address")
        try:
            choice = int(input("Input: "))
            if choice == 1:
                self.__username = input("New username: ").strip()
                print("Updated.")
            elif choice == 2:
                self.__password = input("New password: ").strip()
                print("Updated.")
            elif choice == 3:
                self.__address = input("New address: ").strip()
                print("Updated.")
            else:
                print("Invalid choice.")
        except ValueError:
            print("Please enter a number.")

    # Patient management helpers
    def get_patient_details(self):
        first_name = input("Enter first name: ").strip()
        surname = input("Enter surname: ").strip()
        age = input("Enter age: ").strip()
        mobile = input("Enter mobile: ").strip()
        postcode = input("Enter postcode: ").strip()
        address = input("Enter address: ").strip()
        symptoms = input("Enter symptoms: ").strip()
        family_id = input("Enter family ID (or leave blank): ").strip()
        return first_name, surname, age, mobile, postcode, address, symptoms, family_id

    def register_patient(self, patients):
        print("-----Register Patient-----")
        first_name, surname, age, mobile, postcode, address, symptoms, family_id = self.get_patient_details()
        try:
            age = int(age)
            new_patient = Patient(first_name, surname, age, mobile, postcode, address, symptoms, family_id)
            patients.append(new_patient)
            print("Patient registered successfully.")
        except ValueError:
            print("Invalid age. Patient not registered.")

    def update_patient(self, patients):
        if not patients:
            print("No patients to update.")
            return
        print("-----Update Patient-----")
        self.view_patient(patients)
        try:
            idx = int(input("Select Patient ID: ")) - 1
            if not self.find_index(idx, patients):
                print("Invalid patient ID.")
                return

            print("Choose field to update:")
            print(" 1 First name")
            print(" 2 Surname")
            print(" 3 Age")
            print(" 4 Mobile")
            print(" 5 Postcode")
            print(" 6 Address")
            print(" 7 Symptoms")
            print(" 8 Family ID")

            choice = input("Input: ").strip()
            patient = patients[idx]

            if choice == '1':
                patient.set_first_name(input("New first name: ").strip())
            elif choice == '2':
                patient.set_surname(input("New surname: ").strip())
            elif choice == '3':
                try:
                    patient.set_age(int(input("New age: ").strip()))
                except ValueError:
                    print("Invalid age.")
                    return
            elif choice == '4':
                patient.set_mobile(input("New mobile: ").strip())
            elif choice == '5':
                patient.set_postcode(input("New postcode: ").strip())
            elif choice == '6':
                patient.set_address(input("New address: ").strip())
            elif choice == '7':
                patient.set_symptoms(input("New symptoms: ").strip())
            elif choice == '8':
                patient.set_family_id(input("New family ID: ").strip())
            else:
                print("Invalid choice.")
                return
            print("Patient updated.")
        except ValueError:
            print("Please enter a number.")

    def delete_patient(self, patients, doctors):
        if not patients:
            print("No patients to delete.")
            return
        print("-----Delete Patient-----")
        self.view_patient(patients)
        try:
            idx = int(input("Select Patient ID: ")) - 1
            if not self.find_index(idx, patients):
                print("Invalid patient ID.")
                return

            patient = patients[idx]
            for doctor in doctors:
                doctor.remove_patient(patient)

            removed = patients.pop(idx)
            print(f"Deleted: {removed.full_name()}")
        except ValueError:
            print("Please enter a number.")

    def relocate_patient(self, patients, doctors):
        if not patients or not doctors:
            print("Need both patients and doctors.")
            return

        print("-----Relocate Patient-----")
        self.view_patient(patients)
        try:
            p_idx = int(input("Patient ID: ")) - 1
            if not self.find_index(p_idx, patients):
                print("Invalid patient ID.")
                return
        except ValueError:
            print("Please enter a number.")
            return

        patient = patients[p_idx]
        print(f"Current doctor: {patient.get_doctor()}")

        print("\n-----Available Doctors-----")
        print("ID |          Full Name           |  Speciality")
        self.view(doctors)
        try:
            d_idx = int(input("New Doctor ID: ")) - 1
            if not self.find_index(d_idx, doctors):
                print("Invalid doctor ID.")
                return
        except ValueError:
            print("Please enter a number.")
            return

        for doctor in doctors:
            doctor.remove_patient(patient)

        new_doctor = doctors[d_idx]
        patient.link(new_doctor.full_name())
        new_doctor.add_patient(patient)
        print(f"Patient relocated to Dr. {new_doctor.full_name()}")

    def view_patients_by_family(self, patients):
        print("-----Patients by Family-----")
        families = defaultdict(list)

        for patient in patients:
            family_id = patient.get_family_id() if patient.get_family_id() else "No Family"
            families[family_id].append(patient)

        for family_id, members in families.items():
            print(f"\nFamily ID: {family_id}")
            print("ID |          Full Name           |      Doctor's Full Name      | Age |    Mobile     | Postcode")
            for idx, patient in enumerate(members, start=1):
                print(f"{idx:3} | {patient}")

    def add_appointment(self, doctors):
        if not doctors:
            print("No doctors available.")
            return

        print("-----Add Appointment-----")
        print("ID |          Full Name           |  Speciality")
        self.view(doctors)

        try:
            d_idx = int(input("Doctor ID: ")) - 1
            if not self.find_index(d_idx, doctors):
                print("Invalid doctor ID.")
                return

            month = input("Enter month (e.g., January, February): ").strip()
            doctors[d_idx].add_appointment(month)
            print(f"Appointment added for Dr. {doctors[d_idx].full_name()} in {month}")
        except ValueError:
            print("Please enter a number.")

    def generate_report(self, doctors, patients):
        print("\n" + "="*60)
        print("          HOSPITAL MANAGEMENT REPORT")
        print("="*60)

        total_doctors = len(doctors)
        print(f"\na) Total number of doctors: {total_doctors}")

        print(f"\nb) Patients per doctor:")
        for idx, doctor in enumerate(doctors, start=1):
            patient_count = sum(1 for p in patients if p.get_doctor() == doctor.full_name())
            print(f"   {idx}. Dr. {doctor.full_name()}: {patient_count} patients")

        print(f"\nc) Appointments per month:")
        for idx, doctor in enumerate(doctors, start=1):
            appointments = doctor.get_appointments()
            print(f"   {idx}. Dr. {doctor.full_name()}:")
            if appointments:
                for month, count in appointments.items():
                    print(f"      - {month}: {count} appointments")
            else:
                print(f"      - No appointments recorded")

        print(f"\nd) Patients by illness type:")
        illness_count = defaultdict(int)
        for patient in patients:
            symptoms = patient.get_symptoms()
            if symptoms:
                illness_count[symptoms] += 1
            else:
                illness_count["No symptoms recorded"] += 1

        for illness, count in illness_count.items():
            print(f"   - {illness}: {count} patients")

        print("\n" + "="*60)

    def save_data(self, doctors, patients, discharged_patients, filename='hospital_data.json'):
        try:
            data = {
                'doctors': [doctor.to_dict() for doctor in doctors],
                'patients': [patient.to_dict() for patient in patients],
                'discharged_patients': [patient.to_dict() for patient in discharged_patients]
            }
            with open(filename, 'w') as f:
                json.dump(data, f, indent=4)
            print(f"Data saved successfully to {filename}")
        except Exception as e:
            print(f"Error saving data: {e}")

    def load_data(self, filename='hospital_data.json'):
        try:
            if not os.path.exists(filename):
                print(f"No data file found: {filename}")
                return [], [], []

            with open(filename, 'r') as f:
                data = json.load(f)

            doctors = [Doctor.from_dict(d) for d in data.get('doctors', [])]
            patients = [Patient.from_dict(p) for p in data.get('patients', [])]
            discharged_patients = [Patient.from_dict(p) for p in data.get('discharged_patients', [])]

            print(f"Data loaded successfully from {filename}")
            return doctors, patients, discharged_patients
        except Exception as e:
            print(f"Error loading data: {e}")
            return [], [], []

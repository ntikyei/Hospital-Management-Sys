import tkinter as tk
from tkinter import messagebox, simpledialog
import json
from collections import defaultdict


class Doctor:
    def __init__(self, first_name, surname, speciality):
        self.first_name = first_name
        self.surname = surname
        self.speciality = speciality
        self.appointments = {}  # month -> count

    def full_name(self):
        return f"{self.first_name} {self.surname}"

    def __str__(self):
        return f"{self.full_name()} | {self.speciality}"

    def add_appointment(self, month):
        if month in self.appointments:
            self.appointments[month] += 1
        else:
            self.appointments[month] = 1

    def to_dict(self):
        return {
            "first_name": self.first_name,
            "surname": self.surname,
            "speciality": self.speciality,
            "appointments": self.appointments,
        }

    @staticmethod
    def from_dict(data):
        d = Doctor(data["first_name"], data["surname"], data["speciality"])
        d.appointments = data.get("appointments", {})
        return d


class Patient:
    def __init__(self, first_name, surname, age, mobile, address, symptoms="", family_id=""):
        self.first_name = first_name
        self.surname = surname
        self.age = age
        self.mobile = mobile
        self.address = address
        self.symptoms = symptoms
        self.family_id = family_id
        self.doctor_name = "None"

    def full_name(self):
        return f"{self.first_name} {self.surname}"

    def __str__(self):
        return f"{self.full_name()} | Doctor: {self.doctor_name} | Age: {self.age} | {self.mobile} | {self.address}"

    def to_dict(self):
        return {
            "first_name": self.first_name,
            "surname": self.surname,
            "age": self.age,
            "mobile": self.mobile,
            "address": self.address,
            "symptoms": self.symptoms,
            "family_id": self.family_id,
            "doctor_name": self.doctor_name,
        }

    @staticmethod
    def from_dict(data):
        p = Patient(
            data["first_name"],
            data["surname"],
            data["age"],
            data["mobile"],
            data["address"],
            data.get("symptoms", ""),
            data.get("family_id", ""),
        )
        p.doctor_name = data.get("doctor_name", "None")
        return p


class HospitalApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Hospital Management System")

        
        self.admin_user = "admin"
        self.admin_pass = "123"

        self.data_file = "hospital_data_gui.json"

        loaded = self.load_data()
        if loaded:
            self.doctors, self.patients, self.discharged = loaded
        else:
            self.doctors = [
                Doctor("John", "Smith", "Internal Med."),
                Doctor("Jone", "Smith", "Pediatrics"),
                Doctor("Jone", "Carlos", "Cardiology"),
                Doctor("Joshua", "Tutu", "Neurology"),
                Doctor("Emily", "Brown", "Dermatology"),
                Doctor("Liam", "Turner", "Orthopedics"),
                Doctor("Aisha", "Khan", "Emergency Med."),
                Doctor("Carlos", "Mendes", "Oncology"),
            ]

            self.patients = [
                Patient("Sara", "Smith", 20, "07012345678", "B1 234", "Headache", "FAM001"),
                Patient("Mike", "Jones", 37, "07555551234", "L2 2AB", "Cough", "FAM002"),
                Patient("David", "Smith", 15, "07123456789", "C1 ABC", "Fever", "FAM001"),
                Patient("Laura", "Bennett", 42, "07888880001", "D4 1XZ", "Chest pain", "FAM003"),
                Patient("Noah", "Clarke", 29, "07999990002", "E3 9JK", "Back pain", "FAM004"),
                Patient("Priya", "Patel", 33, "07000001111", "F7 5GH", "Allergy", "FAM005"),
                Patient("Henry", "Williams", 58, "07111112222", "G2 8LM", "Diabetes follow-up", "FAM006"),
                Patient("Sofia", "Garcia", 24, "07222223333", "H5 3NP", "Migraine", "FAM007"),
            ]

            self.discharged = []

        self.login_frame = None
        self.menu_frame = None
        self.show_login()

    
    def show_login(self):
        if self.menu_frame:
            self.menu_frame.destroy()

        self.login_frame = tk.Frame(self.root, padx=16, pady=16)
        self.login_frame.pack(fill="both", expand=True)

        tk.Label(self.login_frame, text="Login", font=("Segoe UI", 14, "bold")).grid(row=0, column=0, columnspan=2, pady=8)

        tk.Label(self.login_frame, text="Username:").grid(row=1, column=0, sticky="e", padx=6, pady=6)
        tk.Label(self.login_frame, text="Password:").grid(row=2, column=0, sticky="e", padx=6, pady=6)

        self.user_var = tk.StringVar()
        self.pass_var = tk.StringVar()

        tk.Entry(self.login_frame, textvariable=self.user_var).grid(row=1, column=1, padx=6, pady=6)
        tk.Entry(self.login_frame, textvariable=self.pass_var, show="*").grid(row=2, column=1, padx=6, pady=6)

        tk.Button(self.login_frame, text="Login", width=12, command=self.login).grid(row=3, column=0, columnspan=2, pady=10)

    def login(self):
        u = self.user_var.get().strip()
        p = self.pass_var.get().strip()
        if u == self.admin_user and p == self.admin_pass:
            messagebox.showinfo("Login", "Login successful.")
            self.login_frame.destroy()
            self.show_menu()
        else:
            messagebox.showerror("Login", "Invalid username or password.")

    def show_menu(self):
        self.menu_frame = tk.Frame(self.root, padx=16, pady=16)
        self.menu_frame.pack(fill="both", expand=True)

        tk.Label(self.menu_frame, text="Admin Menu", font=("Segoe UI", 14, "bold")).grid(row=0, column=0, columnspan=2, pady=8)

        
        tk.Label(self.menu_frame, text="Doctor Management", font=("Segoe UI", 11, "bold")).grid(row=1, column=0, sticky="w", pady=(10, 4))
        tk.Button(self.menu_frame, text="Register Doctor", width=22, command=self.register_doctor).grid(row=2, column=0, sticky="w", pady=2)
        tk.Button(self.menu_frame, text="View Doctors", width=22, command=self.view_doctors).grid(row=3, column=0, sticky="w", pady=2)
        tk.Button(self.menu_frame, text="Update Doctor", width=22, command=self.update_doctor).grid(row=4, column=0, sticky="w", pady=2)
        tk.Button(self.menu_frame, text="Delete Doctor", width=22, command=self.delete_doctor).grid(row=5, column=0, sticky="w", pady=2)

        
        tk.Label(self.menu_frame, text="Patient Management", font=("Segoe UI", 11, "bold")).grid(row=1, column=1, sticky="w", pady=(10, 4), padx=(20, 0))
        tk.Button(self.menu_frame, text="Register Patient", width=22, command=self.register_patient).grid(row=2, column=1, sticky="w", pady=2, padx=(20, 0))
        tk.Button(self.menu_frame, text="View Patients", width=22, command=self.view_patients).grid(row=3, column=1, sticky="w", pady=2, padx=(20, 0))
        tk.Button(self.menu_frame, text="Update Patient", width=22, command=self.update_patient).grid(row=4, column=1, sticky="w", pady=2, padx=(20, 0))
        tk.Button(self.menu_frame, text="Delete Patient", width=22, command=self.delete_patient).grid(row=5, column=1, sticky="w", pady=2, padx=(20, 0))
        tk.Button(self.menu_frame, text="Assign Doctor", width=22, command=self.assign_doctor).grid(row=6, column=1, sticky="w", pady=2, padx=(20, 0))
        tk.Button(self.menu_frame, text="Relocate Patient", width=22, command=self.relocate_patient).grid(row=7, column=1, sticky="w", pady=2, padx=(20, 0))
        tk.Button(self.menu_frame, text="Discharge Patient", width=22, command=self.discharge_patient).grid(row=8, column=1, sticky="w", pady=2, padx=(20, 0))

        tk.Button(self.menu_frame, text="View Discharged", width=22, command=self.view_discharged).grid(row=9, column=1, sticky="w", pady=8, padx=(20, 0))
        tk.Button(self.menu_frame, text="View Families", width=22, command=self.view_families).grid(row=10, column=1, sticky="w", pady=2, padx=(20, 0))
        tk.Button(self.menu_frame, text="Add Appointment", width=22, command=self.add_appointment).grid(row=11, column=1, sticky="w", pady=2, padx=(20, 0))
        tk.Button(self.menu_frame, text="Report", width=22, command=self.generate_report).grid(row=12, column=1, sticky="w", pady=2, padx=(20, 0))
        tk.Button(self.menu_frame, text="Save Data", width=22, command=self.save_data).grid(row=13, column=1, sticky="w", pady=2, padx=(20, 0))
        tk.Button(self.menu_frame, text="Logout", width=22, command=self.logout).grid(row=14, column=1, sticky="w", pady=8, padx=(20, 0))

    def logout(self):
        if self.menu_frame:
            self.menu_frame.destroy()
        self.show_login()

    
    def register_doctor(self):
        first = simpledialog.askstring("Doctor", "First name:")
        if not first:
            return
        last = simpledialog.askstring("Doctor", "Surname:")
        if not last:
            return
        spec = simpledialog.askstring("Doctor", "Speciality:")
        if not spec:
            return
        self.doctors.append(Doctor(first.strip(), last.strip(), spec.strip()))
        messagebox.showinfo("Doctor", "Doctor registered.")

    def view_doctors(self):
        if not self.doctors:
            messagebox.showinfo("Doctors", "No doctors available.")
            return
        lines = ["ID | Full Name | Speciality", "------------------------------------"]
        for i, d in enumerate(self.doctors, start=1):
            lines.append(f"{i}. {d.full_name()} | {d.speciality}")
        messagebox.showinfo("Doctors", "\n".join(lines))

    def update_doctor(self):
        if not self.doctors:
            messagebox.showinfo("Update", "No doctors to update.")
            return
        self.view_doctors()
        try:
            idx = simpledialog.askinteger("Update Doctor", "Enter Doctor ID:", minvalue=1, maxvalue=len(self.doctors))
            if not idx:
                return
            d = self.doctors[idx - 1]
            new_first = simpledialog.askstring("Update", f"New first name (blank to keep '{d.first_name}'):")
            new_last = simpledialog.askstring("Update", f"New surname (blank to keep '{d.surname}'):")
            new_spec = simpledialog.askstring("Update", f"New speciality (blank to keep '{d.speciality}'):")
            if new_first is not None and new_first.strip() != "":
                d.first_name = new_first.strip()
            if new_last is not None and new_last.strip() != "":
                d.surname = new_last.strip()
            if new_spec is not None and new_spec.strip() != "":
                d.speciality = new_spec.strip()
            messagebox.showinfo("Update", "Doctor updated.")
        except Exception:
            messagebox.showerror("Error", "Invalid input.")

    def delete_doctor(self):
        if not self.doctors:
            messagebox.showinfo("Delete", "No doctors to delete.")
            return
        self.view_doctors()
        idx = simpledialog.askinteger("Delete Doctor", "Enter Doctor ID:", minvalue=1, maxvalue=len(self.doctors))
        if not idx:
            return
        removed = self.doctors.pop(idx - 1)
        
        for p in self.patients:
            if p.doctor_name == removed.full_name():
                p.doctor_name = "None"
        messagebox.showinfo("Delete", f"Removed: {removed.full_name()}")

    
    def view_patients(self):
        if not self.patients:
            messagebox.showinfo("Patients", "No patients available.")
            return
        lines = ["ID | Full Name | Doctor | Age | Mobile | Address", "---------------------------------------------------------"]
        for i, p in enumerate(self.patients, start=1):
            lines.append(f"{i}. {p.full_name()} | {p.doctor_name} | {p.age} | {p.mobile} | {p.address}")
        messagebox.showinfo("Patients", "\n".join(lines))

    def update_patient(self):
        if not self.patients:
            messagebox.showinfo("Update", "No patients to update.")
            return
        self.view_patients()
        try:
            idx = simpledialog.askinteger("Update Patient", "Enter Patient ID:", minvalue=1, maxvalue=len(self.patients))
            if not idx:
                return
            p = self.patients[idx - 1]
            new_first = simpledialog.askstring("Update", f"New first name (blank to keep '{p.first_name}'):")
            new_last = simpledialog.askstring("Update", f"New surname (blank to keep '{p.surname}'):")
            new_age = simpledialog.askstring("Update", f"New age (blank to keep '{p.age}'):")
            new_mobile = simpledialog.askstring("Update", f"New mobile (blank to keep '{p.mobile}'):")
            new_addr = simpledialog.askstring("Update", f"New address (blank to keep '{p.address}'):")
            new_sym = simpledialog.askstring("Update", f"New symptoms (blank to keep current)")
            new_fam = simpledialog.askstring("Update", f"New family ID (blank to keep '{p.family_id}'):")

            if new_first is not None and new_first.strip() != "":
                p.first_name = new_first.strip()
            if new_last is not None and new_last.strip() != "":
                p.surname = new_last.strip()
            if new_age is not None and new_age.strip() != "":
                try:
                    p.age = int(new_age.strip())
                except ValueError:
                    messagebox.showwarning("Age", "Age must be a number. Keeping old value.")
            if new_mobile is not None and new_mobile.strip() != "":
                p.mobile = new_mobile.strip()
            if new_addr is not None and new_addr.strip() != "":
                p.address = new_addr.strip()
            if new_sym is not None and new_sym.strip() != "":
                p.symptoms = new_sym.strip()
            if new_fam is not None and new_fam.strip() != "":
                p.family_id = new_fam.strip()

            messagebox.showinfo("Update", "Patient updated.")
        except Exception:
            messagebox.showerror("Error", "Invalid input.")

    def delete_patient(self):
        if not self.patients:
            messagebox.showinfo("Delete", "No patients to delete.")
            return
        self.view_patients()
        idx = simpledialog.askinteger("Delete Patient", "Enter Patient ID:", minvalue=1, maxvalue=len(self.patients))
        if not idx:
            return
        removed = self.patients.pop(idx - 1)
        messagebox.showinfo("Delete", f"Removed: {removed.full_name()}")

    def register_patient(self):
        try:
            first = simpledialog.askstring("Patient", "First name:")
            if not first:
                return
            last = simpledialog.askstring("Patient", "Surname:")
            if not last:
                return
            age = simpledialog.askinteger("Patient", "Age:", minvalue=0, maxvalue=150)
            if age is None:
                return
            mobile = simpledialog.askstring("Patient", "Mobile:") or ""
            address = simpledialog.askstring("Patient", "Address:") or ""
            symptoms = simpledialog.askstring("Patient", "Symptoms:") or ""
            family_id = simpledialog.askstring("Patient", "Family ID (optional):") or ""
            p = Patient(first.strip(), last.strip(), age, mobile.strip(), address.strip(), symptoms.strip(), family_id.strip())
            self.patients.append(p)
            messagebox.showinfo("Patient", "Patient registered.")
        except Exception:
            messagebox.showerror("Error", "Invalid input.")

    def assign_doctor(self):
        if not self.patients or not self.doctors:
            messagebox.showinfo("Assign", "Need both patients and doctors.")
            return
        self.view_patients()
        p_idx = simpledialog.askinteger("Assign", "Patient ID:", minvalue=1, maxvalue=len(self.patients))
        if not p_idx:
            return
        self.view_doctors()
        d_idx = simpledialog.askinteger("Assign", "Doctor ID:", minvalue=1, maxvalue=len(self.doctors))
        if not d_idx:
            return
        patient = self.patients[p_idx - 1]
        doctor = self.doctors[d_idx - 1]
        patient.doctor_name = doctor.full_name()
        messagebox.showinfo("Assign", "Doctor assigned to patient.")

    def relocate_patient(self):
        if not self.patients or not self.doctors:
            messagebox.showinfo("Relocate", "Need both patients and doctors.")
            return
        self.view_patients()
        p_idx = simpledialog.askinteger("Relocate", "Patient ID:", minvalue=1, maxvalue=len(self.patients))
        if not p_idx:
            return
        self.view_doctors()
        d_idx = simpledialog.askinteger("Relocate", "New Doctor ID:", minvalue=1, maxvalue=len(self.doctors))
        if not d_idx:
            return
        patient = self.patients[p_idx - 1]
        new_doc = self.doctors[d_idx - 1]
        patient.doctor_name = new_doc.full_name()
        messagebox.showinfo("Relocate", f"Patient moved to Dr. {new_doc.full_name()}")

    def discharge_patient(self):
        if not self.patients:
            messagebox.showinfo("Discharge", "No patients to discharge.")
            return
        self.view_patients()
        idx = simpledialog.askinteger("Discharge", "Enter Patient ID:", minvalue=1, maxvalue=len(self.patients))
        if not idx:
            return
        patient = self.patients.pop(idx - 1)
        self.discharged.append(patient)
        messagebox.showinfo("Discharge", f"Discharged: {patient.full_name()}")

    def view_discharged(self):
        if not self.discharged:
            messagebox.showinfo("Discharged", "No discharged patients.")
            return
        lines = ["ID | Full Name | Doctor | Age | Mobile | Address", "---------------------------------------------------------"]
        for i, p in enumerate(self.discharged, start=1):
            lines.append(f"{i}. {p.full_name()} | {p.doctor_name} | {p.age} | {p.mobile} | {p.address}")
        messagebox.showinfo("Discharged", "\n".join(lines))

    def view_families(self):
        if not self.patients:
            messagebox.showinfo("Families", "No patients available.")
            return
        groups = defaultdict(list)
        for p in self.patients:
            key = p.family_id if p.family_id else "No Family"
            groups[key].append(p)
        lines = []
        for fam, members in groups.items():
            lines.append(f"Family: {fam}")
            for m in members:
                lines.append(f"  - {m.full_name()} | Doctor: {m.doctor_name} | Age: {m.age} | {m.symptoms}")
            lines.append("")
        messagebox.showinfo("Families", "\n".join(lines))

    def add_appointment(self):
        if not self.doctors:
            messagebox.showinfo("Appointments", "No doctors available.")
            return
        self.view_doctors()
        d_idx = simpledialog.askinteger("Appointment", "Doctor ID:", minvalue=1, maxvalue=len(self.doctors))
        if not d_idx:
            return
        month = simpledialog.askstring("Appointment", "Month (e.g., January):")
        if not month:
            return
        self.doctors[d_idx - 1].add_appointment(month.strip())
        messagebox.showinfo("Appointments", "Appointment recorded.")

    def generate_report(self):
        total_doctors = len(self.doctors)
        patients_per_doc = []
        for d in self.doctors:
            count = sum(1 for p in self.patients if p.doctor_name == d.full_name())
            patients_per_doc.append(f"Dr. {d.full_name()}: {count}")

        appt_lines = []
        for d in self.doctors:
            if d.appointments:
                for month, cnt in d.appointments.items():
                    appt_lines.append(f"Dr. {d.full_name()} - {month}: {cnt}")
            else:
                appt_lines.append(f"Dr. {d.full_name()} - No appointments")

        illness = defaultdict(int)
        for p in self.patients:
            key = p.symptoms if p.symptoms else "No symptoms"
            illness[key] += 1

        msg = [
            f"Total doctors: {total_doctors}",
            "Patients per doctor:",
            *patients_per_doc,
            "",
            "Appointments per month per doctor:",
            *appt_lines,
            "",
            "Patients by illness type:",
        ]
        for k, v in illness.items():
            msg.append(f"{k}: {v}")
        messagebox.showinfo("Report", "\n".join(msg))

    def save_data(self):
        try:
            data = {
                "doctors": [d.to_dict() for d in self.doctors],
                "patients": [p.to_dict() for p in self.patients],
                "discharged": [p.to_dict() for p in self.discharged],
            }
            with open(self.data_file, "w") as f:
                json.dump(data, f, indent=2)
            messagebox.showinfo("Save", "Data saved.")
        except Exception:
            messagebox.showerror("Save", "Could not save data.")

    def load_data(self):
        try:
            with open(self.data_file, "r") as f:
                data = json.load(f)
            doctors = [Doctor.from_dict(d) for d in data.get("doctors", [])]
            patients = [Patient.from_dict(p) for p in data.get("patients", [])]
            discharged = [Patient.from_dict(p) for p in data.get("discharged", [])]
            return doctors, patients, discharged
        except FileNotFoundError:
            return None
        except Exception:
            messagebox.showerror("Load", "Could not load data, starting fresh.")
            return None


if __name__ == "__main__":
    root = tk.Tk()
    app = HospitalApp(root)
    root.mainloop()
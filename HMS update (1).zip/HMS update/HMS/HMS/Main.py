# Imports
from Admin import Admin
from Doctor import Doctor
from Patient import Patient


def main():
    admin = Admin('admin', '123', 'B1 1AB')

    # Try to load existing data
    print("Loading data...")
    doctors, patients, discharged_patients = admin.load_data()

    # If no data loaded, use default data
    if not doctors:
        doctors = [
            Doctor('John', 'Smith', 'Internal Med.'),
            Doctor('Jone', 'Smith', 'Pediatrics'),
            Doctor('Jone', 'Carlos', 'Cardiology'),
            Doctor('Joshua', 'Tutu', 'Neurology'),
            Doctor('Emily', 'Brown', 'Dermatology'),
            Doctor('Liam', 'Turner', 'Orthopedics'),
            Doctor('Aisha', 'Khan', 'Emergency Med.'),
            Doctor('Carlos', 'Mendes', 'Oncology')
        ]

    if not patients:
        patients = [
            Patient('Sara', 'Smith', 20, '07012345678', 'B1 234', '123 Main St', 'Headache', 'FAM001'),
            Patient('Mike', 'Jones', 37, '07555551234', 'L2 2AB', '456 Oak Ave', 'Cough', 'FAM002'),
            Patient('David', 'Smith', 15, '07123456789', 'C1 ABC', '123 Main St', 'Fever', 'FAM001'),
            Patient('Laura', 'Bennett', 42, '07888880001', 'D4 1XZ', '789 Pine Rd', 'Chest pain', 'FAM003'),
            Patient('Noah', 'Clarke', 29, '07999990002', 'E3 9JK', '22 Elm St', 'Back pain', 'FAM004'),
            Patient('Priya', 'Patel', 33, '07000001111', 'F7 5GH', '15 Market Sq', 'Allergy', 'FAM005'),
            Patient('Henry', 'Williams', 58, '07111112222', 'G2 8LM', '3 River Walk', 'Diabetes follow-up', 'FAM006'),
            Patient('Sofia', 'Garcia', 24, '07222223333', 'H5 3NP', '9 Orchard Ln', 'Migraine', 'FAM007')
        ]

    while True:
        print("\n=== Hospital Management System ===")
        print("1. Login as Admin")
        print("2. Save and Exit")
        print("0. Exit without saving")
        choice = input("Input: ").strip()

        if choice == '0':
            print("Goodbye.")
            break
        elif choice == '2':
            admin.save_data(doctors, patients, discharged_patients)
            print("Goodbye.")
            break
        elif choice != '1':
            print("Invalid option.")
            continue

        if not admin.login():
            print("Login failed.")
            continue

        while True:
            print("\n--- Admin Menu ---")
            print("1. Doctor management")
            print("2. Patient management")
            print("3. View patients")
            print("4. Assign doctor to patient")
            print("5. Relocate patient to another doctor")
            print("6. Discharge patient")
            print("7. View discharged patients")
            print("8. View patients by family")
            print("9. Add appointment")
            print("10. Generate management report")
            print("11. Update admin details")
            print("12. Save data")
            print("0. Logout")
            op = input("Input: ").strip()

            if op == '1':
                admin.doctor_management(doctors, patients)
            elif op == '2':
                print("\n--- Patient Management ---")
                print("1. Register new patient")
                print("2. Update patient")
                print("3. Delete patient")
                sub_op = input("Input: ").strip()
                if sub_op == '1':
                    admin.register_patient(patients)
                elif sub_op == '2':
                    admin.update_patient(patients)
                elif sub_op == '3':
                    admin.delete_patient(patients, doctors)
            elif op == '3':
                admin.view_patient(patients)
            elif op == '4':
                admin.assign_doctor_to_patient(patients, doctors)
            elif op == '5':
                admin.relocate_patient(patients, doctors)
            elif op == '6':
                admin.discharge(patients, discharged_patients, doctors)
            elif op == '7':
                admin.view_discharge(discharged_patients)
            elif op == '8':
                admin.view_patients_by_family(patients)
            elif op == '9':
                admin.add_appointment(doctors)
            elif op == '10':
                admin.generate_report(doctors, patients)
            elif op == '11':
                admin.update_details()
            elif op == '12':
                admin.save_data(doctors, patients, discharged_patients)
            elif op == '0':
                print("Logged out.")
                break
            else:
                print("Invalid option.")


if __name__ == '__main__':
    main()